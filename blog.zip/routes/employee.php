<?php

// Route::get('/home', function () {
// dd(1);

   

    // return view('employee.home');
// })->name('home');

Route::get('/home', 'EmployeeHomeController@index')->name('home');