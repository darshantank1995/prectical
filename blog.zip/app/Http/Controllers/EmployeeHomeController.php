<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;
use Illuminate\Pagination\LengthAwarePaginator;

class EmployeeHomeController extends Controller
{
  public function index(Request $request)
  {

        $this->data['page'] = !empty($request->page) ? $request->page : '1';
        $this->data['perpage'] = "10";
        $offset = ($this->data['page'] - 1) * $this->data['perpage'];

        $client = new \GuzzleHttp\Client();

         $url="https://api.github.com/users?per_page=10&since=".$this->data['page'];
    
        $request = $client->get($url);

  
        $response = json_decode($request->getBody()->getContents(),true);


        $this->data['lists']=  $response;
      

    return view('employee.home',$this->data);
  }  //
}
