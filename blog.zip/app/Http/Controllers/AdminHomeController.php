<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Employee;

class AdminHomeController extends Controller
{
   
  public function index(Request $request)
  {
    $this->data['lists']=  Employee::all();
    return view('admin.home',$this->data);
  }

}
