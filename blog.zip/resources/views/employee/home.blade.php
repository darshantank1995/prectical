@extends('employee.layout.auth')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    {{--  You are logged in as Employee!  --}}
                    Customer List
                </div>

                <table class="table">
                    @foreach ($lists as $list)
                    <tr>
                        <td><img style="width: 100px;height:100px" src="{{  $list['avatar_url'] ?? "" }}"/><td/>
                        <td>{{  $list['login'] ?? "" }}<td/>
                        <td>{{  $list['login'] ?? "" }}<td/>
                    </tr>
                    @endforeach
                  
                </table>

                 @php $pageno = $page + 1; @endphp
                  <a href="?per_page=10&since={{ $pageno }}">next</a>



            </div>
        </div>
    </div>
</div>
@endsection
