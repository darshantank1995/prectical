<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    
                    Customer List
                </div>

                <table class="table">
                    <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img style="width: 100px;height:100px" src="<?php echo e($list['avatar_url'] ?? ""); ?>"/><td/>
                        <td><?php echo e($list['login'] ?? ""); ?><td/>
                        <td><?php echo e($list['login'] ?? ""); ?><td/>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </table>

                 <?php $pageno = $page + 1; ?>
                  <a href="?per_page=10&since=<?php echo e($pageno); ?>">next</a>



            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\blog\resources\views/employee/home.blade.php ENDPATH**/ ?>